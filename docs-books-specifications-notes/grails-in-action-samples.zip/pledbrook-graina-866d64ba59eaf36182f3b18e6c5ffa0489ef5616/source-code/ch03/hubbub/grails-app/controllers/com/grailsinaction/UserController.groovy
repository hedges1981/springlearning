package com.grailsinaction

class UserController {

    def scaffold = true
}
