Grails in Action - Chapter 2 examples
-------------------------------------

The examples in this directory are mainly Groovy scripts, although
CopingWithLineBreaks.groovy is a class. To run the examples, first
make sure that Groovy is installed and is on your path. Then simply
run:

  groovy <filename>

For example:

  groovy closures.groovy

