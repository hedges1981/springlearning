class QuoteControllerTests extends GroovyTestCase {

    void testSomething() {

    }
}
