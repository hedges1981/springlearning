class QuoteTests extends GroovyTestCase {

    void testSomething() {

    }
}
