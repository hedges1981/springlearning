package com.grailsinaction

class PostController {

    def scaffold = true

}
