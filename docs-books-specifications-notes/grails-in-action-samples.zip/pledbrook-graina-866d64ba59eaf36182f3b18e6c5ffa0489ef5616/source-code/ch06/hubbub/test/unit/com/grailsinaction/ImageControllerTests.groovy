package com.grailsinaction

import grails.test.*

class ImageControllerTests extends grails.test.GrailsUnitTestCase {

    void testSomething() {

    }
}
