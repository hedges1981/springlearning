package com.grailsinaction

class ReplyController {
    def scaffold = true
}
