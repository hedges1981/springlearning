package com.grailsinaction

class Reply {
    Post post
    User user
}
