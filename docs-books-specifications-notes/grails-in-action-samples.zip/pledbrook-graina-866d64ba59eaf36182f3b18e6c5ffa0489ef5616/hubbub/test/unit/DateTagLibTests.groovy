import grails.test.*

class DateTagLibTests extends grails.test.GrailsUnitTestCase {

    void testSomething() {

    }
}
