import grails.test.*

class LameSecurityFiltersTests extends grails.test.GrailsUnitTestCase {

    void testSomething() {

    }
}
