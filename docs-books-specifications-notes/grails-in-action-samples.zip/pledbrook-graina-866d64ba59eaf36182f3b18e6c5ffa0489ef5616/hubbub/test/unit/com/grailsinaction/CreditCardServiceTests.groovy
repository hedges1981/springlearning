package com.grailsinaction

import grails.test.*

class CreditCardServiceTests extends grails.test.GrailsUnitTestCase {

    void testSomething() {

    }
}
