package com.grailsinaction

import grails.test.*

class ProfileControllerTests extends grails.test.GrailsUnitTestCase {

    void testSomething() {

    }
}
