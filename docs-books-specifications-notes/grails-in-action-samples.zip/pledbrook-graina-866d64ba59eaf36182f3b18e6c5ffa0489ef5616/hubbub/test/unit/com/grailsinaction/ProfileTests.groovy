package com.grailsinaction

import grails.test.*

class ProfileTests extends grails.test.GrailsUnitTestCase {

    void testSomething() {

    }
}
