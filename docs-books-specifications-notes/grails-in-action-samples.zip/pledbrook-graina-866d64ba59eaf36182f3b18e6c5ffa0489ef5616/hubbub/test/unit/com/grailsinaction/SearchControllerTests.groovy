package com.grailsinaction

import grails.test.*

class SearchControllerTests extends grails.test.GrailsUnitTestCase {

    void testSomething() {

    }
}
