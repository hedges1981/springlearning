package com.grailsinaction

import grails.test.*

class TagTests extends grails.test.GrailsUnitTestCase {

    void testSomething() {

    }
}
