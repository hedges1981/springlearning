class DailyDigestJobTests extends GroovyTestCase {

    void testSomething() {

    }
}
