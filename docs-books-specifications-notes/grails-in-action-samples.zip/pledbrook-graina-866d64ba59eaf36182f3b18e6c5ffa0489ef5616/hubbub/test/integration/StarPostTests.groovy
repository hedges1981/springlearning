class StarPostTests extends GroovyTestCase {

    void testSomething() {

    }
}
