class MessageTests extends GroovyTestCase {

    void testSomething() {

    }
}
