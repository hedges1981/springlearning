class JabberGatewayServiceTests extends GroovyTestCase {

    void testSomething() {

    }
}
