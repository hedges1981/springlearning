import grails.test.*

@artifact.package@class @artifact.name@ extends grails.test.GrailsUnitTestCase {

    void testSomething() {

    }
}
