@artifact.package@class @artifact.name@ {

    boolean transactional = true

    def serviceMethod() {

    }
}
