drop table PERSON if exists;
create table PERSON (ID integer identity primary key, NAME varchar(50) not null);
